<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetalleOdontograma extends Model
{
    //
}
